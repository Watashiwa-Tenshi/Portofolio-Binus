List anggota kelompok :
1. Jansen Chandra (2502008870)
2. Kevin Riedo (2502013990)

Untuk file figma, ada file yang bernama Project HCI.fig

Quotes1 : https://www.brainyquote.com/quotes/aaron_siskind_141150
Quotes2 : https://petapixel.com/photography-quotes/

gallery1.jpg : https://www.visitnsw.com/destinations/south-coast/kiama-area/gerringong/attractions/south-werri-ourie-ocean-pool-gerringong
gallery3.jpg : http://picmelon.com/freestockimages/animals/flamingo-couple-passion-dance/
gallery4.jpg : https://awol.junkee.com/2019-travel-destinations-aussies/67675
gallery5.jpg : https://www.etsy.com/listing/1114140304/colorful-african-tribal-dress-art-poster
gallery6.jpg : https://www.pexels.com/photo/man-surfing-on-ocean-waves-1650732/
gallery7.jpg : https://www.pinterest.com/pin/731060952005561320/
gallery8.jpg : https://tafisa.ca/en/our-colours/hot-fudge
project-main.jpg : https://bestaccreditedcolleges.org/articles/how-to-become-a-movie-director.html
project-1.jpg : https://www.pexels.com/photo/man-holding-video-camera-2773498/
project-2.jpg : https://images.app.goo.gl/xHd9mijfp2LQLjcG8
header.jpg : https://pxhere.com/en/photo/1410194
insta-1.jpg : https://freerangestock.com/photos/131840/taking-picture-with-canon-camera-.html
insta-2.jpg : https://www.creativebloq.com/deals/4-ways-freelancing-can-change-your-life-for-the-better
insta-3.jpg : https://www.photospecialist.ie/products/studio/studio-lighting
insta-4.jpg : https://personalbrandingphotography.academy/personal-branding-blog/mistakes-personal-brand-photographers-make