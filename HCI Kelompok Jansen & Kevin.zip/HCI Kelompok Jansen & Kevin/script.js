const showBtn = document.querySelector('.navBtn');
const topNav = document.querySelector('.top-nav');

showBtn.addEventListener('click', function(){
    if(topNav.classList.contains('showNav')){
        topNav.classList.remove('showNav');
        showBtn.innerHTML = '<i class = "fas fa-bars"></i>';
    } else {
        topNav.classList.add('showNav');
        showBtn.innerHTML = '<i class = "fas fa-times"></i>';
    }
});

function validate() {
    var name = document.reg_form.name;
    var country = document.reg_form.country;
    var gender = document.reg_form.gender;
    var email = document.reg_form.email;
    var mobile = document.reg_form.mobile;
    var terms = document.reg_form.terms;
    var letters = /^[A-Za-z]+$/;
    var validMail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (name.value.length <= 0) {
        alert("Name is required");
        name.focus();
        return false;
    }

    if (!name.value.match(letters)){
        alert("Please input alphabet characters only in the name field");
        name.focus();
        return false;
    }

    if (country.value.length <= 0) {
        alert("Country is required");
        country.focus();
        return false;
    }

    if (gender.value.length <= 0) {
        alert("Gender is required");
        gender.focus();
        return false;
    }

    if (email.value.length <= 0) {
        alert("Email Id is required");
        email.focus();
        return false;
    }

    if (!email.value.match(validMail)){
        alert("Invalid email address!");
        return false;
    }

    if (mobile.value.length <= 0) {
        alert("Mobile number is required");
        mobile.focus();
        return false;
    }

    if (!terms.checked) {
        alert("You must agree with our Terms and Conditions");
        terms.focus();
        return false;
    }

    alert("Thank you for your subscription");
    return false;
}